"""
FX自動取引システム — ペーパートレード起動スクリプト

全コンポーネントを接続し、MT5デモ口座で自動取引を実行する。
Phase 2 ペーパートレードの本番起動用。複数通貨ペア同時監視対応。

使用方法:
    # デフォルト（USD_JPY, EUR_USD, GBP_JPY を H4 で監視）
    python main.py

    # 単一通貨ペア指定（後方互換）
    python main.py --instrument USD_JPY

    # 複数通貨ペア指定
    python main.py --instruments USD_JPY EUR_USD GBP_JPY EUR_JPY

    # 時間足とチェック間隔を変更
    python main.py --instruments USD_JPY EUR_USD --granularity H1 --interval 30

    # ドライラン（MT5接続テストのみ、取引しない）
    python main.py --dry-run

    # ドライラン（単一ペア）
    python main.py --instrument EUR_USD --dry-run
"""

import argparse
import logging
import signal
import sys
import time
from pathlib import Path

from typing import Optional

from src.config import (
    DB_PATH, DEFAULT_INSTRUMENTS, MAIN_TIMEFRAME,
    TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, TELEGRAM_ENABLED,
)
from src.mt5_client import Mt5Client, Mt5ClientError
from src.position_manager import PositionManager
from src.risk_manager import RiskManager
from src.strategy.ma_crossover import RsiMaCrossover
from src.telegram_notifier import TelegramNotifier, TelegramLogHandler
from src.trading_loop import TradingLoop

logger = logging.getLogger("fx_auto_trading")

# 1ペアあたりの連続エラー上限
MAX_CONSECUTIVE_ERRORS = 10


def setup_logging(verbose: bool = False) -> None:
    """ログ設定を初期化する。"""
    console_level = logging.DEBUG if verbose else logging.INFO

    # ルートロガー設定（常にDEBUG — ファイルには全て記録）
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    # コンソールハンドラ（verboseフラグで制御）
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(console_level)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)-8s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    console.setFormatter(fmt)
    root.addHandler(console)

    # ファイルハンドラ（data/ディレクトリに出力）
    log_dir = Path(__file__).resolve().parent / "data"
    log_dir.mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(
        log_dir / "trading.log", encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)


def parse_args() -> argparse.Namespace:
    """コマンドライン引数をパースする。"""
    parser = argparse.ArgumentParser(
        description="FX自動取引システム — ペーパートレード（複数通貨ペア対応）",
    )
    parser.add_argument(
        "--instruments",
        nargs="+",
        default=None,
        help=(
            "監視する通貨ペアのリスト（スペース区切り）。"
            f"デフォルト: {' '.join(DEFAULT_INSTRUMENTS)}"
        ),
    )
    parser.add_argument(
        "--instrument",
        default=None,
        help="単一通貨ペア指定（後方互換）。--instruments より優先。",
    )
    parser.add_argument(
        "--granularity",
        default=MAIN_TIMEFRAME,
        help=f"タイムフレーム（デフォルト: {MAIN_TIMEFRAME}）",
    )
    parser.add_argument(
        "--interval",
        type=int,
        default=60,
        help="チェック間隔（秒、デフォルト: 60）",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="ドライラン: MT5接続テストのみ実行し、取引ループは開始しない",
    )
    parser.add_argument(
        "--test-trade",
        action="store_true",
        help=(
            "テストトレード: 最小ロット(0.01)で1回だけ注文→即決済し、"
            "注文パイプライン全体を検証する"
        ),
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="DEBUGレベルのログを出力",
    )
    return parser.parse_args()


def resolve_instruments(args: argparse.Namespace) -> list[str]:
    """引数から監視対象の通貨ペアリストを解決する。"""
    if args.instrument:
        # --instrument（単一指定）が優先
        return [args.instrument]
    if args.instruments:
        return args.instruments
    # どちらも未指定ならデフォルト
    return list(DEFAULT_INSTRUMENTS)


def dry_run(
    client: Mt5Client, instruments: list[str], granularity: str
) -> None:
    """MT5接続テスト（取引せず接続・データ取得のみ確認）"""
    logger.info("=== ドライラン開始 ===")

    # 1. 口座情報取得（全ペア共通）
    logger.info("--- 1. 口座情報取得 ---")
    account = client.get_account_summary()
    logger.info(
        "口座残高: %.2f %s | 未実現損益: %.2f | "
        "使用証拠金: %.2f | 利用可能証拠金: %.2f",
        account["balance"],
        account.get("currency", "???"),
        account["unrealized_pl"],
        account["margin_used"],
        account["margin_available"],
    )

    # 2. 保有ポジション確認（全ペア共通）
    logger.info("--- 2. 保有ポジション確認 ---")
    positions = client.get_positions()
    if positions:
        for pos in positions:
            logger.info(
                "  trade_id=%s, instrument=%s, units=%d, pl=%.2f",
                pos["trade_id"],
                pos["instrument"],
                pos["units"],
                pos["unrealized_pl"],
            )
    else:
        logger.info("保有ポジションなし")

    # 3. 通貨ペア別チェック
    for inst in instruments:
        logger.info("--- [%s] 価格データ取得: %s ---", inst, granularity)
        data = client.get_prices(inst, 100, granularity)
        logger.info("[%s] 取得行数: %d", inst, len(data))
        if len(data) > 0:
            logger.info("[%s] 最新バー: %s", inst, data.iloc[-1].to_dict())
            logger.info(
                "[%s] 時間範囲: %s 〜 %s", inst, data.index[0], data.index[-1]
            )

        spread = client.get_spread(inst)
        if spread is not None:
            logger.info("[%s] スプレッド: %.5f", inst, spread)
        else:
            logger.warning("[%s] スプレッド取得不可", inst)

        strategy = RsiMaCrossover()
        sig = strategy.generate_signal(data)
        logger.info("[%s] シグナル: %s", inst, sig.value)

    logger.info("=== ドライラン完了: 全チェックOK (%d ペア) ===", len(instruments))


def test_trade(client: Mt5Client, instrument: str) -> None:
    """
    テストトレード: シンボル情報を元に正しいパラメータで注文→即決済。

    MT5の symbol_info から最小ロット・ストップレベル・桁数を取得し、
    ブローカーの制約に合った注文を自動構築する。
    """
    import MetaTrader5 as mt5
    from src.mt5_client import to_mt5_symbol

    logger.info("=== テストトレード開始 ===")
    logger.info("対象通貨ペア: %s", instrument)

    symbol = to_mt5_symbol(instrument)

    # 1. シンボル情報を取得 — 全パラメータの根拠にする
    info = mt5.symbol_info(symbol)
    if info is None:
        logger.error("シンボル情報を取得できません: %s", symbol)
        logger.error("MT5のマーケットウォッチに %s を追加してください", symbol)
        return

    # マーケット開場チェック
    # trade_mode: 0=disabled, 4=full (SYMBOL_TRADE_MODE_FULL)
    if info.trade_mode == 0:
        logger.error("取引無効: %s (trade_mode=0)", symbol)
        logger.error("→ マーケットが閉まっている可能性があります（土日・祝日）")
        return

    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        logger.error("ティック情報を取得できません: %s", symbol)
        return

    # スプレッドが0 = ティックが更新されていない = 市場閉場の可能性
    if tick.ask == 0 or tick.bid == 0 or tick.ask == tick.bid:
        logger.error(
            "ティック異常（ask=%.5f, bid=%.5f）: マーケットが閉まっている可能性があります",
            tick.ask, tick.bid,
        )
        return

    # シンボル制約をログ出力
    logger.info("--- シンボル情報: %s ---", symbol)
    logger.info("  trade_mode: %d (4=完全取引可能)", info.trade_mode)
    logger.info("  Ask: %.5f / Bid: %.5f", tick.ask, tick.bid)
    logger.info("  スプレッド: %.5f (%.1f pips)",
                tick.ask - tick.bid,
                (tick.ask - tick.bid) / info.point)
    logger.info("  最小ロット: %.2f / ロットステップ: %.2f",
                info.volume_min, info.volume_step)
    logger.info("  ストップレベル: %d ポイント (= %.5f)",
                info.trade_stops_level,
                info.trade_stops_level * info.point)
    logger.info("  小数桁数: %d / 1ポイント: %.5f",
                info.digits, info.point)
    logger.info("  フィリングモード: %d", info.filling_mode)

    # 2. 口座情報（注文前）
    account_before = client.get_account_summary()
    logger.info("口座残高(注文前): %.2f %s",
                account_before["balance"],
                account_before.get("currency", "???"))

    # 3. 注文パラメータをシンボル情報から計算
    volume = info.volume_min  # 最小ロット
    price = tick.ask          # 買い注文なのでask

    # ストップレベル: 最低距離（ポイント単位）。0の場合はスプレッドの3倍を使う
    stop_level_points = info.trade_stops_level
    if stop_level_points == 0:
        stop_level_points = max(
            int((tick.ask - tick.bid) / info.point * 3), 50
        )

    # SL/TP距離 = ストップレベルの2倍（余裕を持たせる）
    sl_distance = stop_level_points * 2 * info.point
    tp_distance = stop_level_points * 4 * info.point

    stop_loss = round(price - sl_distance, info.digits)
    take_profit = round(price + tp_distance, info.digits)
    units = int(volume * 100_000)  # lot → 通貨単位

    logger.info("--- 注文パラメータ ---")
    logger.info("  volume: %.2f lot (%d units)", volume, units)
    logger.info("  price(ask): %.5f", price)
    logger.info("  SL: %.5f (距離: %.5f = %d pts)",
                stop_loss, sl_distance,
                int(sl_distance / info.point))
    logger.info("  TP: %.5f (距離: %.5f = %d pts)",
                take_profit, tp_distance,
                int(tp_distance / info.point))

    # 4. 買い注文を発注
    logger.info("--- 買い注文を発注 ---")
    try:
        order_result = client.market_order(
            instrument=instrument,
            units=units,
            stop_loss=stop_loss,
            take_profit=take_profit,
        )
    except Mt5ClientError as e:
        logger.error("注文失敗: %s", e)
        return

    trade_id = order_result["trade_id"]
    fill_price = order_result["price"]
    logger.info("注文約定: trade_id=%s, 約定価格=%.5f, status=%s",
                trade_id, fill_price, order_result["status"])

    # 5. ポジション確認
    logger.info("--- ポジション確認 ---")
    positions = client.get_positions()
    test_pos = None
    for pos in positions:
        if pos["trade_id"] == trade_id:
            test_pos = pos
            break

    if test_pos:
        logger.info("ポジション確認OK: instrument=%s, units=%d, pl=%.2f",
                    test_pos["instrument"], test_pos["units"],
                    test_pos["unrealized_pl"])
    else:
        logger.warning("ポジション一覧に trade_id=%s が未反映（ラグの可能性）",
                       trade_id)

    # 6. 即決済
    logger.info("--- ポジション決済 ---")
    time.sleep(2)
    try:
        close_result = client.close_position(trade_id)
    except Mt5ClientError as e:
        logger.error("決済失敗: %s", e)
        return

    logger.info("決済完了: close_price=%.5f, realized_pl=%.2f",
                close_result["close_price"], close_result["realized_pl"])

    # 7. 口座情報（決済後）
    account_after = client.get_account_summary()
    balance_diff = account_after["balance"] - account_before["balance"]

    # 8. サマリー
    logger.info("=" * 50)
    logger.info("テストトレード結果サマリー")
    logger.info("  通貨ペア: %s (%s)", instrument, symbol)
    logger.info("  注文: BUY %.2f lot (%d units)", volume, units)
    logger.info("  約定価格: %.5f → 決済価格: %.5f", fill_price,
                close_result["close_price"])
    logger.info("  スリッページ: %.5f", abs(price - fill_price))
    logger.info("  損益: %.2f", close_result["realized_pl"])
    logger.info("  残高: %.2f → %.2f (差額: %+.2f)",
                account_before["balance"], account_after["balance"],
                balance_diff)
    logger.info("=" * 50)
    logger.info("=== テストトレード完了: パイプライン正常動作確認 ===")


def _register_telegram_commands(
    notifier: TelegramNotifier,
    risk_manager: RiskManager,
) -> None:
    """Telegramコマンドのハンドラを登録する。"""

    def cmd_status(chat_id: str) -> str:
        status = notifier.get_cached_status()
        active = status.get("active_instruments", [])
        ks_active = status.get("kill_switch_active", False)
        ks_reason = status.get("kill_switch_reason", "")
        iteration = status.get("iteration", 0)
        return (
            f"<b>ボット状態</b>\n"
            f"稼働中ペア: {', '.join(active) if active else 'なし'}\n"
            f"イテレーション: #{iteration}\n"
            f"キルスイッチ: {'発動中 (' + ks_reason + ')' if ks_active else '正常'}"
        )

    def cmd_positions(chat_id: str) -> str:
        positions = notifier.get_cached_positions()
        if not positions:
            return "保有ポジションなし"
        lines = ["<b>保有ポジション</b>"]
        for pos in positions:
            lines.append(
                f"  {pos.get('instrument', '?')}: {pos.get('units', 0):+d} units, "
                f"損益: {pos.get('unrealized_pl', 0):+.0f}円"
            )
        return "\n".join(lines)

    def cmd_balance(chat_id: str) -> str:
        account = notifier.get_cached_account()
        if not account:
            return "口座情報がまだ取得できていません"
        return (
            f"<b>口座情報</b>\n"
            f"残高: {account.get('balance', 0):,.0f} "
            f"{account.get('currency', '???')}\n"
            f"未実現損益: {account.get('unrealized_pl', 0):+,.0f}\n"
            f"使用証拠金: {account.get('margin_used', 0):,.0f}\n"
            f"利用可能証拠金: {account.get('margin_available', 0):,.0f}"
        )

    def cmd_stop(chat_id: str) -> str:
        ks = risk_manager.kill_switch
        if ks.is_active:
            return f"キルスイッチは既に発動中です（理由: {ks.reason}）"
        ks.activate("manual")
        return "手動キルスイッチを発動しました。新規取引を停止します。"

    def cmd_start(chat_id: str) -> str:
        ks = risk_manager.kill_switch
        if not ks.is_active:
            return "キルスイッチは発動していません。"
        ks.deactivate()
        return "キルスイッチを解除しました。取引を再開します。"

    def cmd_help(chat_id: str) -> str:
        return (
            "<b>利用可能なコマンド</b>\n"
            "/status - ボット動作状態\n"
            "/positions - 現在のポジション一覧\n"
            "/balance - 口座残高・損益\n"
            "/stop - ボット停止（キルスイッチ発動）\n"
            "/start - ボット再開（キルスイッチ解除）\n"
            "/help - このメッセージ"
        )

    notifier.register_command_handler("status", cmd_status)
    notifier.register_command_handler("positions", cmd_positions)
    notifier.register_command_handler("balance", cmd_balance)
    notifier.register_command_handler("stop", cmd_stop)
    notifier.register_command_handler("start", cmd_start)
    notifier.register_command_handler("help", cmd_help)


def main() -> None:
    """メインエントリーポイント"""
    args = parse_args()
    setup_logging(verbose=args.verbose)

    instruments = resolve_instruments(args)

    logger.info("=" * 60)
    logger.info("FX自動取引システム 起動")
    logger.info(
        "監視通貨ペア: %s (%dペア) | 時間足: %s | 間隔: %d秒",
        ", ".join(instruments),
        len(instruments),
        args.granularity,
        args.interval,
    )
    logger.info("=" * 60)

    # MT5接続
    try:
        client = Mt5Client()
    except Mt5ClientError as e:
        logger.critical("MT5接続失敗: %s", e)
        sys.exit(1)

    notifier: Optional[TelegramNotifier] = None

    try:
        # ドライランモード
        if args.dry_run:
            dry_run(client, instruments, args.granularity)
            return

        # テストトレードモード（最小ロットで注文→即決済）
        if args.test_trade:
            test_instrument = instruments[0]
            logger.info("テストトレード対象: %s", test_instrument)
            test_trade(client, test_instrument)
            return

        # 口座残高を取得して初期化
        account = client.get_account_summary()
        initial_balance = account["balance"]
        logger.info(
            "口座残高: %.2f %s",
            initial_balance,
            account.get("currency", "???"),
        )

        # DB初期化
        db_path = DB_PATH
        db_path.parent.mkdir(parents=True, exist_ok=True)
        logger.info("SQLiteデータベース: %s", db_path)

        # 共有コンポーネント作成（全ペアで1つずつ）
        risk_manager = RiskManager(
            account_balance=initial_balance,
            broker_client=client,
            db_path=db_path,
        )
        position_manager = PositionManager(
            broker_client=client,
            risk_manager=risk_manager,
            db_path=db_path,
        )

        # 通貨ペアごとにTradingLoopを作成
        strategies: dict[str, RsiMaCrossover] = {}
        loops: dict[str, TradingLoop] = {}
        for inst in instruments:
            strategy = RsiMaCrossover()
            strategies[inst] = strategy
            loops[inst] = TradingLoop(
                broker_client=client,
                position_manager=position_manager,
                risk_manager=risk_manager,
                strategy=strategy,
                instrument=inst,
                granularity=args.granularity,
                check_interval_sec=args.interval,
            )

        # Telegram通知初期化（トークン未設定なら無効）
        if TELEGRAM_ENABLED:
            notifier = TelegramNotifier(
                bot_token=TELEGRAM_BOT_TOKEN,
                chat_id=TELEGRAM_CHAT_ID,
            )
            _register_telegram_commands(notifier, risk_manager)
            notifier.start()

            # WARNING以上のログを自動転送するハンドラを追加
            tg_handler = TelegramLogHandler(notifier)
            tg_handler.setFormatter(logging.Formatter("%(name)s: %(message)s"))
            logging.getLogger().addHandler(tg_handler)

            notifier.notify_bot_status(
                "起動", f"{len(instruments)}ペア監視開始"
            )
            logger.info("Telegram通知を有効化しました")
        else:
            logger.info(
                "Telegram通知は無効です"
                "（TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID 未設定）"
            )

        # グレースフルシャットダウン
        running = True

        def graceful_shutdown(signum, frame):
            nonlocal running
            logger.info("シャットダウンシグナルを受信しました (signal=%d)", signum)
            running = False

        signal.signal(signal.SIGINT, graceful_shutdown)
        signal.signal(signal.SIGTERM, graceful_shutdown)

        # マルチペア・ラウンドロビンループ
        logger.info(
            "トレーディングループを開始します（%dペア）。Ctrl+C で停止。",
            len(loops),
        )
        error_counts: dict[str, int] = {inst: 0 for inst in instruments}
        disabled_instruments: set[str] = set()
        iteration = 0

        while running:
            iteration += 1
            active_instruments = [
                inst for inst in instruments if inst not in disabled_instruments
            ]

            if not active_instruments:
                logger.critical("全通貨ペアが停止しました。プログラムを終了します。")
                if notifier:
                    notifier.notify_bot_status(
                        "緊急停止", "全通貨ペアが停止しました"
                    )
                break

            for inst in active_instruments:
                if not running:
                    break
                try:
                    loops[inst].run_once()
                    error_counts[inst] = 0
                except Exception as e:
                    error_counts[inst] += 1
                    logger.error(
                        "[%s] イテレーションエラー (%d/%d): %s",
                        inst,
                        error_counts[inst],
                        MAX_CONSECUTIVE_ERRORS,
                        e,
                        exc_info=True,
                    )
                    if error_counts[inst] > MAX_CONSECUTIVE_ERRORS:
                        logger.critical(
                            "[%s] 連続エラーが上限(%d)を超過。このペアの監視を停止します。",
                            inst,
                            MAX_CONSECUTIVE_ERRORS,
                        )
                        disabled_instruments.add(inst)

            # Telegramキャッシュ更新（コマンドハンドラ用）
            if notifier and running:
                try:
                    cached_account = client.get_account_summary()
                    cached_positions = client.get_positions()
                    ks = risk_manager.kill_switch
                    notifier.update_cache(
                        account=cached_account,
                        positions=cached_positions,
                        status={
                            "active_instruments": list(active_instruments),
                            "kill_switch_active": ks.is_active,
                            "kill_switch_reason": ks.reason if ks.is_active else "",
                            "iteration": iteration,
                        },
                    )
                except Exception:
                    pass  # キャッシュ更新失敗はメインループに影響させない

            # イテレーション完了サマリー（コンソール用INFO）
            if running and active_instruments:
                summary_lines = [f"[#{iteration}]"]
                for inst in active_instruments:
                    diag = strategies[inst].last_diagnostics
                    if diag:
                        reason = diag.get("hold_reason", "---")
                        adx_mark = "OK" if diag["adx"] >= diag["adx_threshold"] else "NG"
                        summary_lines.append(
                            f"  {inst}: MA差{diag['ma_diff']:+.3f} "
                            f"RSI={diag['rsi']:.0f} "
                            f"ADX={diag['adx']:.0f}({adx_mark}) "
                            f"→ {reason if reason else 'SIGNAL!'}"
                        )
                    else:
                        summary_lines.append(f"  {inst}: 診断データなし")
                logger.info("\n".join(summary_lines))

            if running:
                time.sleep(args.interval)

        logger.info(
            "トレーディングループ停止: total_iterations=%d", iteration
        )

    except Exception as e:
        logger.critical("予期しないエラーが発生しました: %s", e, exc_info=True)
        sys.exit(1)

    finally:
        # Telegram停止通知・シャットダウン
        if notifier:
            notifier.notify_bot_status("停止", "プログラムを終了します")
            # 送信キューの処理を少し待つ
            time.sleep(1)
            notifier.stop()

        # 最終ステータス表示
        try:
            final_account = client.get_account_summary()
            logger.info(
                "最終残高: %.2f %s",
                final_account["balance"],
                final_account.get("currency", "???"),
            )
        except Exception:
            pass

        client.close()
        logger.info("MT5接続を切断しました。プログラムを終了します。")


if __name__ == "__main__":
    main()
