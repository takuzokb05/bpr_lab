"""
FX自動取引システム — MetaTrader 5 Python API 実装

BrokerClientインターフェースのMT5実装。
外為ファイネスト + MT5 デモ口座対応。
"""

import logging
import time

import pandas as pd

from src.broker_client import BrokerClient
from src.config import (
    API_MAX_RETRIES,
    MT5_MAGIC_NUMBER,
    MT5_DEVIATION,
    MT5_SYMBOL_SUFFIX,
    MT5_LOT_UNIT,
)

logger = logging.getLogger(__name__)

# MT5はWindows専用。インポート失敗時はエラーメッセージを提供
try:
    import MetaTrader5 as mt5
except ImportError:
    mt5 = None  # type: ignore


class Mt5ClientError(Exception):
    """MT5 API固有のエラー"""


# よくあるMT5エラーコード → 日本語対処法ヒント
_RETCODE_HINTS: dict[int, str] = {
    10027: "MT5ターミナルの「自動売買」ボタンを有効（緑色）にしてください",
    10018: "マーケットが閉まっています（土日・祝日・メンテナンス時間帯）",
    10016: "無効な損切り/利確価格です。ストップレベルを確認してください",
    10014: "無効なロット数です。最小ロット(0.01)以上を指定してください",
    10019: "証拠金が不足しています",
    10006: "注文が拒否されました。ブローカー側の制限を確認してください",
    10004: "リクォート発生。価格が急変しています",
    10013: "無効な注文リクエストです。パラメータを確認してください",
    10015: "無効な価格です。現在のマーケット価格を確認してください",
    10030: "注文の変更が禁止されています",
}


# ================================================================
# シンボル変換
# ================================================================


def to_mt5_symbol(instrument: str) -> str:
    """
    BrokerClient形式のシンボルをMT5形式に変換する。

    例: "USD_JPY" -> "USDJPY-"
    """
    base = instrument.replace("_", "")
    return base + MT5_SYMBOL_SUFFIX


def from_mt5_symbol(mt5_symbol: str) -> str:
    """
    MT5形式のシンボルをBrokerClient形式に変換する。

    例: "USDJPY-" -> "USD_JPY"
    """
    if mt5_symbol.endswith(MT5_SYMBOL_SUFFIX):
        base = mt5_symbol[: -len(MT5_SYMBOL_SUFFIX)]
    else:
        base = mt5_symbol
    # 先頭3文字 + "_" + 残り（FX通貨ペアは6文字）
    return base[:3] + "_" + base[3:]


# ================================================================
# タイムフレーム変換
# ================================================================

_GRANULARITY_MAP: dict[str, str] = {
    "M1": "TIMEFRAME_M1",
    "M5": "TIMEFRAME_M5",
    "M15": "TIMEFRAME_M15",
    "M30": "TIMEFRAME_M30",
    "H1": "TIMEFRAME_H1",
    "H4": "TIMEFRAME_H4",
    "D": "TIMEFRAME_D1",
    "W": "TIMEFRAME_W1",
    "MN": "TIMEFRAME_MN1",
}


def to_mt5_timeframe(granularity: str) -> int:
    """
    BrokerClient形式のタイムフレームをMT5定数に変換する。

    例: "H4" -> mt5.TIMEFRAME_H4

    Raises:
        Mt5ClientError: MetaTrader5パッケージ未インストール
        ValueError: 未対応のタイムフレーム
    """
    if mt5 is None:
        raise Mt5ClientError(
            "MetaTrader5パッケージがインストールされていません。"
        )

    attr_name = _GRANULARITY_MAP.get(granularity)
    if attr_name is None:
        raise ValueError(
            f"未対応のタイムフレーム: {granularity}。"
            f"対応: {', '.join(_GRANULARITY_MAP.keys())}"
        )
    return getattr(mt5, attr_name)


# ================================================================
# MT5Client
# ================================================================


class Mt5Client(BrokerClient):
    """
    MetaTrader 5 Python API の BrokerClient 実装。

    外為ファイネスト MT5 デモ口座対応。
    MT5ターミナルがログイン済みの状態で起動している必要がある。
    """

    def __init__(self) -> None:
        """
        MT5クライアントを初期化し、ターミナルに接続する。

        Raises:
            Mt5ClientError: MT5パッケージ未インストール or ターミナル接続失敗
        """
        if mt5 is None:
            raise Mt5ClientError(
                "MetaTrader5パッケージがインストールされていません。"
                "pip install MetaTrader5 を実行してください。"
            )

        self._initialized = False
        self._ensure_connected()

    def _ensure_connected(self) -> None:
        """MT5ターミナルとの接続を確認し、未接続なら接続する。"""
        if self._initialized:
            return

        if not mt5.initialize():
            error = mt5.last_error()
            raise Mt5ClientError(
                f"MT5ターミナルへの接続に失敗しました: {error}。"
                "MT5ターミナルがログイン済みの状態で起動していることを確認してください。"
            )

        self._initialized = True
        account = mt5.account_info()
        if account:
            logger.info(
                "MT5に接続しました（口座: %s、サーバー: %s、残高: %s %s）",
                account.login,
                account.server,
                account.balance,
                account.currency,
            )
        else:
            logger.warning("MT5に接続しましたが、口座情報を取得できませんでした。")

    def close(self) -> None:
        """MT5ターミナルとの接続を切断する。"""
        if self._initialized:
            mt5.shutdown()
            self._initialized = False
            logger.info("MT5接続を切断しました。")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def _request_with_retry(self, operation, *args, **kwargs):
        """
        リトライ付きでMT5 API操作を実行する。

        order_send の結果は retcode で成否判定。
        それ以外は None で失敗判定。

        Args:
            operation: 実行するMT5 API関数
            *args, **kwargs: 関数に渡す引数

        Returns:
            API操作の結果

        Raises:
            Mt5ClientError: 最大リトライ回数超過 or リトライ不可能なエラー
        """
        last_error = None

        for attempt in range(API_MAX_RETRIES + 1):
            self._ensure_connected()
            result = operation(*args, **kwargs)

            if result is not None:
                # order_sendの結果: retcodeで成否判定
                if hasattr(result, "retcode"):
                    if result.retcode == mt5.TRADE_RETCODE_DONE:
                        return result
                    last_error = (
                        f"retcode={result.retcode}, comment={result.comment}"
                    )
                    # リトライ可能なエラー
                    if result.retcode in (
                        mt5.TRADE_RETCODE_REQUOTE,
                        mt5.TRADE_RETCODE_TIMEOUT,
                        mt5.TRADE_RETCODE_CONNECTION,
                    ):
                        if attempt < API_MAX_RETRIES:
                            wait = 2**attempt
                            logger.warning(
                                "MT5注文エラー（%s）。%d秒後にリトライします（試行 %d/%d）",
                                last_error,
                                wait,
                                attempt + 1,
                                API_MAX_RETRIES + 1,
                            )
                            time.sleep(wait)
                            continue
                    # リトライ不可能なエラー
                    hint = _RETCODE_HINTS.get(result.retcode, "")
                    error_msg = f"MT5注文エラー: {last_error}"
                    if hint:
                        error_msg += f"\n  → 対処法: {hint}"
                    raise Mt5ClientError(error_msg)
                else:
                    # データ取得成功
                    return result

            # result is None → エラー
            error = mt5.last_error()
            last_error = f"error_code={error}"

            if attempt < API_MAX_RETRIES:
                wait = 2**attempt
                logger.warning(
                    "MT5 APIエラー（%s）。%d秒後にリトライします（試行 %d/%d）",
                    last_error,
                    wait,
                    attempt + 1,
                    API_MAX_RETRIES + 1,
                )
                # 接続が切れた可能性 → 再初期化を試みる
                self._initialized = False
                time.sleep(wait)
                continue

        raise Mt5ClientError(
            f"最大リトライ回数({API_MAX_RETRIES})を超過しました。"
            f"最後のエラー: {last_error}"
        )

    # ================================================================
    # BrokerClient インターフェース実装
    # ================================================================

    def get_prices(
        self,
        instrument: str,
        count: int,
        granularity: str,
    ) -> pd.DataFrame:
        """
        OHLCV価格データを取得する。

        Args:
            instrument: 通貨ペア（例: "USD_JPY"）
            count: 取得するローソク足の本数
            granularity: 時間足（例: "H4", "D", "M15"）

        Returns:
            OHLCV形式のDataFrame。カラム: open, high, low, close, volume
            インデックス: datetime（UTC）
        """
        symbol = to_mt5_symbol(instrument)
        timeframe = to_mt5_timeframe(granularity)

        rates = self._request_with_retry(
            mt5.copy_rates_from_pos, symbol, timeframe, 0, count
        )

        if len(rates) == 0:
            logger.warning(
                "価格データが空です: instrument=%s, granularity=%s",
                instrument,
                granularity,
            )
            return pd.DataFrame(
                columns=["open", "high", "low", "close", "volume"]
            )

        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
        df.set_index("time", inplace=True)
        df.index = df.index.tz_localize(None)  # UTC前提でtz除去

        # MT5の tick_volume を volume にリネーム
        df = df.rename(columns={"tick_volume": "volume"})

        return df[["open", "high", "low", "close", "volume"]]

    def market_order(
        self,
        instrument: str,
        units: int,
        stop_loss: float,
        take_profit: float,
    ) -> dict:
        """
        成行注文を発注する。SL/TPは必須。

        Args:
            instrument: 通貨ペア（例: "USD_JPY"）
            units: 取引数量（正=買い、負=売り）
            stop_loss: 損切り価格
            take_profit: 利確価格

        Returns:
            {"order_id": str, "trade_id": str, "price": float,
             "units": int, "status": str} を含むdict
        """
        if units == 0:
            raise ValueError(
                "units が0のため注文できません。ポジションサイズを確認してください。"
            )

        symbol = to_mt5_symbol(instrument)
        volume = round(abs(units) / MT5_LOT_UNIT, 2)

        if volume <= 0:
            raise ValueError(
                f"ロット数が0になりました: units={units}, "
                f"lot_unit={MT5_LOT_UNIT}。最小取引単位に満たないためお取引できません。"
            )

        # 買い/売りの判定 + 約定価格の取得
        self._ensure_connected()
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            raise Mt5ClientError(
                f"ティック情報を取得できません: {symbol}"
            )

        if units > 0:
            order_type = mt5.ORDER_TYPE_BUY
            price = tick.ask
        else:
            order_type = mt5.ORDER_TYPE_SELL
            price = tick.bid

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "price": price,
            "sl": float(stop_loss),
            "tp": float(take_profit),
            "deviation": MT5_DEVIATION,
            "magic": MT5_MAGIC_NUMBER,
            "comment": "FX Auto Trading",
            # type_time は TRADE_ACTION_PENDING（指値注文）専用。
            # TRADE_ACTION_DEAL（成行注文）に含めると retcode=10013 になる。
            "type_filling": mt5.ORDER_FILLING_FOK,  # 仮設定（後で自動判定）
        }

        logger.debug("order_send リクエスト: %s", request)
        result = self._send_order_with_filling_retry(request)

        return {
            "order_id": str(result.order),
            "trade_id": str(result.order),
            "price": result.price,
            "units": units,
            "status": "filled",
        }

    def limit_order(
        self,
        instrument: str,
        units: int,
        price: float,
        stop_loss: float,
        take_profit: float,
    ) -> dict:
        """
        指値注文を発注する。SL/TPは必須。

        Args:
            instrument: 通貨ペア（例: "USD_JPY"）
            units: 取引数量（正=買い、負=売り）
            price: 指値価格
            stop_loss: 損切り価格
            take_profit: 利確価格

        Returns:
            {"order_id": str, "price": float, "units": int, "status": str}
        """
        if units == 0:
            raise ValueError(
                "units が0のため注文できません。ポジションサイズを確認してください。"
            )

        symbol = to_mt5_symbol(instrument)
        volume = round(abs(units) / MT5_LOT_UNIT, 2)

        if volume <= 0:
            raise ValueError(
                f"ロット数が0になりました: units={units}, "
                f"lot_unit={MT5_LOT_UNIT}。最小取引単位に満たないためお取引できません。"
            )

        if units > 0:
            order_type = mt5.ORDER_TYPE_BUY_LIMIT
        else:
            order_type = mt5.ORDER_TYPE_SELL_LIMIT

        request = {
            "action": mt5.TRADE_ACTION_PENDING,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "price": price,
            "sl": float(stop_loss),
            "tp": float(take_profit),
            "deviation": MT5_DEVIATION,
            "magic": MT5_MAGIC_NUMBER,
            "comment": "FX Auto Trading",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_FOK,
        }

        request = self._find_valid_filling(request)

        logger.debug("order_send リクエスト: %s", request)
        result = self._send_order_with_filling_retry(request)

        return {
            "order_id": str(result.order),
            "price": price,
            "units": units,
            "status": "pending",
        }

    def get_positions(self) -> list[dict]:
        """
        保有ポジション一覧を取得する。

        Returns:
            ポジション情報のリスト。各dictは以下を含む:
            - "trade_id": str
            - "instrument": str
            - "units": int（正=買い、負=売り）
            - "unrealized_pl": float
            - "open_price": float
        """
        self._ensure_connected()
        positions = mt5.positions_get()

        if positions is None:
            error = mt5.last_error()
            raise Mt5ClientError(
                f"ポジション情報を取得できませんでした: {error}。"
                "MT5ターミナルの接続状態を確認してください。"
            )

        result = []
        for pos in positions:
            # type: 0=BUY（正）, 1=SELL（負）
            pos_units = int(pos.volume * MT5_LOT_UNIT)
            if pos.type == 1:
                pos_units = -pos_units

            result.append(
                {
                    "trade_id": str(pos.ticket),
                    "instrument": from_mt5_symbol(pos.symbol),
                    "units": pos_units,
                    "unrealized_pl": pos.profit,
                    "open_price": pos.price_open,
                }
            )

        return result

    def close_position(self, trade_id: str) -> dict:
        """
        指定したポジションを決済する。

        Args:
            trade_id: 決済対象のトレードID（MT5のチケット番号）

        Returns:
            {"trade_id": str, "realized_pl": float, "close_price": float}
        """
        self._ensure_connected()
        ticket = int(trade_id)

        # ポジション情報を取得
        positions = mt5.positions_get(ticket=ticket)
        if positions is None or len(positions) == 0:
            raise Mt5ClientError(
                f"ポジションが見つかりません: trade_id={trade_id}"
            )

        pos = positions[0]
        symbol = pos.symbol

        # 反対方向の注文で決済
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            raise Mt5ClientError(
                f"ティック情報を取得できません: {symbol}"
            )

        if pos.type == 0:  # BUY → SELLで決済
            order_type = mt5.ORDER_TYPE_SELL
            price = tick.bid
        else:  # SELL → BUYで決済
            order_type = mt5.ORDER_TYPE_BUY
            price = tick.ask

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": pos.volume,
            "type": order_type,
            "position": ticket,
            "price": price,
            "deviation": MT5_DEVIATION,
            "magic": MT5_MAGIC_NUMBER,
            "comment": "Close position",
            # type_time は TRADE_ACTION_PENDING（指値注文）専用。
            # TRADE_ACTION_DEAL（成行注文）に含めると retcode=10013 になる。
            "type_filling": mt5.ORDER_FILLING_FOK,
        }

        logger.debug("order_send リクエスト(決済): %s", request)
        result = self._send_order_with_filling_retry(request)

        return {
            "trade_id": trade_id,
            "realized_pl": pos.profit,
            "close_price": result.price,
        }

    def get_spread(self, instrument: str) -> float | None:
        """
        現在のbid-askスプレッドを取得する。

        MT5の symbol_info_tick() から bid/ask を取得し、差分を返す。

        Args:
            instrument: 通貨ペア（例: "USD_JPY"）

        Returns:
            スプレッド値（ask - bid）。取得失敗時は None。
        """
        self._ensure_connected()
        symbol = to_mt5_symbol(instrument)
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            logger.warning("スプレッド取得失敗（ティック情報なし）: %s", symbol)
            return None
        spread = tick.ask - tick.bid
        if spread < 0:
            logger.warning("スプレッドが負の値: %s, bid=%.5f, ask=%.5f", symbol, tick.bid, tick.ask)
            return None
        return spread

    def get_account_summary(self) -> dict:
        """
        口座残高・証拠金情報を取得する。

        Returns:
            口座情報のdict:
            - "balance": float
            - "unrealized_pl": float
            - "margin_used": float
            - "margin_available": float
            - "open_trade_count": int
            - "currency": str
        """
        self._ensure_connected()
        account = mt5.account_info()

        if account is None:
            raise Mt5ClientError(
                f"口座情報を取得できませんでした: {mt5.last_error()}"
            )

        positions = mt5.positions_get()
        open_count = len(positions) if positions is not None else 0

        return {
            "balance": account.balance,
            "unrealized_pl": account.profit,
            "margin_used": account.margin,
            "margin_available": account.margin_free,
            "open_trade_count": open_count,
            "currency": account.currency,
        }

    # ================================================================
    # 内部ヘルパー
    # ================================================================

    def _send_order_with_filling_retry(self, request: dict):
        """
        フィリングタイプを変えながら order_send をリトライする。

        order_check が機能しないブローカー（外為ファイネスト等）向け。
        FOK → IOC → RETURN の順に order_send を直接試みる。

        また、Market Execution モードのブローカーでは price を
        指定すると retcode=10013 になる場合があるため、
        10013 が返り続けた場合は price=0 で再試行する。
        """
        filling_types = [
            (mt5.ORDER_FILLING_FOK, "FOK"),
            (mt5.ORDER_FILLING_IOC, "IOC"),
            (mt5.ORDER_FILLING_RETURN, "RETURN"),
        ]

        last_result = None

        # --- 第1ラウンド: 指定 price でフィリングタイプを順番に試す ---
        for filling, name in filling_types:
            request["type_filling"] = filling
            self._ensure_connected()
            result = mt5.order_send(request)
            if result is None:
                err = mt5.last_error()
                logger.warning("order_send(%s) APIエラー: %s", name, err)
                continue
            if result.retcode == mt5.TRADE_RETCODE_DONE:
                logger.info("order_send(%s) 成功: retcode=%d", name, result.retcode)
                return result
            last_result = result
            logger.warning(
                "order_send(%s) 失敗: retcode=%d, comment=%s",
                name, result.retcode, result.comment,
            )
            # リクォート・タイムアウト以外はフィリング変更で回避できないため次へ
            if result.retcode not in (
                mt5.TRADE_RETCODE_REQUOTE,
                mt5.TRADE_RETCODE_TIMEOUT,
                mt5.TRADE_RETCODE_CONNECTION,
                10013,  # Invalid request — フィリングが原因の可能性
            ):
                break

        # --- 第2ラウンド: price=0 で Market Execution として試す ---
        # Market Execution ブローカーでは price 指定が不要/禁止な場合がある
        if last_result is not None and last_result.retcode == 10013:
            logger.warning(
                "全フィリングで retcode=10013。"
                "Market Execution モードとして price=0 で再試行します。"
            )
            request_no_price = dict(request)
            request_no_price["price"] = 0.0
            for filling, name in filling_types:
                request_no_price["type_filling"] = filling
                self._ensure_connected()
                result = mt5.order_send(request_no_price)
                if result is None:
                    err = mt5.last_error()
                    logger.warning(
                        "order_send(price=0, %s) APIエラー: %s", name, err
                    )
                    continue
                if result.retcode == mt5.TRADE_RETCODE_DONE:
                    logger.info(
                        "order_send(price=0, %s) 成功: retcode=%d", name, result.retcode
                    )
                    return result
                last_result = result
                logger.warning(
                    "order_send(price=0, %s) 失敗: retcode=%d, comment=%s",
                    name, result.retcode, result.comment,
                )

        # 全て失敗
        if last_result is not None:
            retcode = last_result.retcode
            hint = _RETCODE_HINTS.get(retcode, "")
            error_msg = (
                f"MT5注文エラー: retcode={retcode}, comment={last_result.comment}"
            )
            if hint:
                error_msg += f"\n  → 対処法: {hint}"
            raise Mt5ClientError(error_msg)

        raise Mt5ClientError(
            "order_send が全て None を返しました。MT5との接続を確認してください。"
        )

    def _find_valid_filling(self, request: dict) -> dict:
        """
        使用するフィリングタイプを判定してリクエストにセットする。

        まず order_check で FOK→IOC→RETURN の順に試す。
        ブローカーによっては order_check が常に失敗（retcode=10013等）する場合があるため、
        全て失敗した場合は symbol_info().filling_mode のビットフラグから判断する。
        それも取得できない場合は RETURN をデフォルトとして使用する。
        """
        filling_types = [
            (mt5.ORDER_FILLING_FOK, "FOK"),
            (mt5.ORDER_FILLING_IOC, "IOC"),
            (mt5.ORDER_FILLING_RETURN, "RETURN"),
        ]

        # --- Step 1: order_check で検証 ---
        for filling, name in filling_types:
            request["type_filling"] = filling
            check = mt5.order_check(request)
            if check is None:
                err = mt5.last_error()
                logger.warning(
                    "order_check(%s) APIエラー: %s", name, err
                )
                continue
            if check.retcode == 0:
                logger.debug("フィリングタイプ %s で事前検証OK", name)
                return request
            logger.warning(
                "order_check(%s) 失敗: retcode=%d, comment=%s",
                name, check.retcode, check.comment,
            )

        # --- Step 2: order_check が全て失敗 → filling_mode ビットフラグで判断 ---
        # ブローカーによっては order_check が機能しない場合がある（例: 外為ファイネストデモ）
        logger.warning(
            "order_check が全フィリングタイプで失敗。"
            "symbol_info().filling_mode からフォールバック判定を試みます。"
        )

        symbol = request.get("symbol", "")
        sym_info = mt5.symbol_info(symbol) if symbol else None

        if sym_info is not None:
            # filling_mode はビットフラグ: bit0=FOK(1), bit1=IOC(2), bit2=RETURN(4)
            filling_mode = sym_info.filling_mode
            logger.warning(
                "symbol_info().filling_mode = %d (symbol=%s)", filling_mode, symbol
            )
            # FOK=1, IOC=2, RETURN=4 のビット確認
            if filling_mode & 1:  # FOK
                request["type_filling"] = mt5.ORDER_FILLING_FOK
                logger.warning("フォールバック: FOK を使用します")
                return request
            if filling_mode & 2:  # IOC
                request["type_filling"] = mt5.ORDER_FILLING_IOC
                logger.warning("フォールバック: IOC を使用します")
                return request
            if filling_mode & 4:  # RETURN
                request["type_filling"] = mt5.ORDER_FILLING_RETURN
                logger.warning("フォールバック: RETURN を使用します")
                return request

        # --- Step 3: それでも判断できない場合は RETURN をデフォルトとして使用 ---
        logger.warning(
            "filling_mode 判定も失敗。デフォルト RETURN で order_send を試みます。"
        )
        request["type_filling"] = mt5.ORDER_FILLING_RETURN
        return request
