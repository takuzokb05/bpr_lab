# VPS + OpenClaw + FX自動化検証環境 構築計画書

## 概要

ノートPCを常時起動させずに、VPS上でOpenClaw Gatewayを24時間稼働させ、
スマホ（Telegram等）からFX戦略の検証・監視を指示できる環境を構築する。

---

## 構成図

```
[スマホ] ←Telegram/Discord→ [VPS]
                                ├── OpenClaw Gateway
                                ├── MT5 (Wine)
                                └── FX検証スクリプト群
```

---

## ステップ1：VPS調達

### 推奨スペック

| 項目 | 最低要件 | 推奨 |
|------|---------|------|
| CPU | 1コア | 2コア |
| RAM | 1GB | 2GB |
| ストレージ | 20GB | 40GB |
| OS | Ubuntu 22.04 LTS | Ubuntu 22.04 LTS |
| 月額 | 約200円〜 | 約500円〜 |

### 候補サービス

- **ConoHa VPS**（国内、低遅延、月額660円〜）
- **さくらのVPS**（国内、月額643円〜）
- **Hetzner Cloud**（海外、月額約350円〜、コスパ最強）
- **Vultr / DigitalOcean**（海外、$6〜/月）

### ユーザー作業（手動必須）

- [ ] VPSプロバイダーでアカウント作成・支払い設定
- [ ] Ubuntu 22.04 LTSでVPSを作成
- [ ] SSHキーの設定（パスワード認証は無効化推奨）
- [ ] SSH接続できることを確認

**ここまで完了したらClaude Codeに引き渡す。**

---

## ステップ2：サーバー基本設定（Claude Code担当）

### 2-1. 初期セキュリティ設定

```bash
# 非rootユーザー作成
# SSHポート変更（任意）
# UFWファイアウォール設定
# fail2ban導入
```

### 2-2. 基本パッケージ導入

```bash
apt update && apt upgrade -y
apt install -y curl git build-essential tmux wget unzip
```

### 2-3. Node.js 22 導入

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt install -y nodejs
```

---

## ステップ3：OpenClaw Gateway 構築（Claude Code担当）

### 3-1. インストール

```bash
npm install -g openclaw@latest
openclaw --version
```

### 3-2. オンボーディング

```bash
openclaw onboard
```

オンボーディング中に設定する項目：

- **LLMモデル選択**：Claude APIキー or Gemini（無料枠あり）
- **通知チャンネル**：Telegram Bot Token + Chat ID（または Discord Webhook）
- **Gateway Bind**：0.0.0.0（外部アクセス用）

### 3-3. 常時起動設定（systemd）

```ini
# /etc/systemd/system/openclaw.service
[Unit]
Description=OpenClaw Gateway
After=network.target

[Service]
Type=simple
User=ubuntu
ExecStart=/usr/local/bin/openclaw gateway
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

```bash
systemctl enable openclaw
systemctl start openclaw
```

---

## ステップ4：MT5 + FX検証環境（Claude Code担当）

### 4-1. Wine導入

```bash
dpkg --add-architecture i386
apt install -y wine wine32 winetricks
```

### 4-2. MT5インストール

```bash
# MT5インストーラーをダウンロードしてWine経由で実行
wget https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe
wine mt5setup.exe
```

※ ヘッドレス環境ではXvfb（仮想ディスプレイ）が必要

```bash
apt install -y xvfb
Xvfb :99 -screen 0 1024x768x24 &
export DISPLAY=:99
wine mt5setup.exe
```

### 4-3. OpenClaw × MT5 連携Skill

OpenClawのSkillとしてMT5制御スクリプトを登録：

- バックテスト実行
- 現在ポジション確認
- 損益レポート取得
- EA（自動売買）の起動/停止

---

## ステップ5：Telegram Bot設定（ユーザー作業 + Claude Code）

### ユーザー作業（手動必須）

- [ ] [@BotFather](https://t.me/BotFather) でBotを作成
- [ ] Bot Token を取得
- [ ] 自分のChat IDを確認（[@userinfobot](https://t.me/userinfobot)で取得可能）

### Claude Code担当

- OpenClawオンボーディングにToken/Chat IDを設定
- テストメッセージ送受信の確認

---

## ステップ6：動作確認

### 確認項目

- [ ] スマホのTelegramからメッセージを送ってOpenClawが応答する
- [ ] `openclaw gateway`がsystemdで自動再起動される
- [ ] MT5がWine上で起動する
- [ ] バックテスト結果をTelegramに返してくれる

---

## セキュリティ注意事項

- APIキーは`.env`ファイルに保存し、`chmod 600`で保護
- OpenClaw GatewayのポートはFirewallで制限（必要IPのみ許可、またはTailscale経由）
- MT5のAPIキー・ブローカーパスワードも同様に管理
- VPSのrootログインは無効化

---

## コスト試算

| 項目 | 月額 |
|------|------|
| VPS（Hetzner CX22） | 約350円 |
| Claude API（個人利用程度） | 約500〜1,000円 |
| **合計** | **約850〜1,350円** |

Gemini APIの無料枠を使えばLLMコストはゼロにできる。

---

## Claude Codeへの引き渡し情報テンプレート

```
以下の情報でVPS + OpenClaw + MT5環境を構築してください。

## 接続情報
- VPS IP: xxx.xxx.xxx.xxx
- SSHユーザー: ubuntu
- SSHキー: ~/.ssh/id_rsa（ローカル）

## 使用するLLM
- [ ] Claude API（APIキー: sk-ant-...）
- [ ] Gemini API（APIキー: ...）
- [ ] その他: 

## 通知チャンネル
- [ ] Telegram（Bot Token: ..., Chat ID: ...）
- [ ] Discord（Webhook URL: ...）

## MT5
- [ ] 必要（ブローカー: XXX）
- [ ] 不要（後で追加）

## 優先度
1. OpenClaw Gateway を systemd で常時起動
2. Telegram連携の確認
3. MT5セットアップ（余裕があれば）
```

---

*作成日：2026-02-28*
