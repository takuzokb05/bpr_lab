# FX自動取引システム

外為ファイネスト MT5 デモ口座で動作する Python ベースの FX 自動取引システム。

## 概要

- **ブローカー**: 外為ファイネスト（GaitameFinest）MT5 デモ口座
- **戦略**: RSI + 移動平均クロスオーバー（ADXフィルター付き）
- **対応通貨ペア**: USD/JPY, EUR/USD, GBP/JPY, AUD/USD, EUR/JPY, GBP/USD
- **時間足**: H4（4時間足）
- **リスク管理**: 1トレード最大1%リスク、最大3同時ポジション、5段階ドローダウン制御

## 動作要件

- Windows（MetaTrader5 Python API は Windows 専用）
- MT5 ターミナル（外為ファイネスト版）がログイン済みで起動中であること
- Python 3.11+
- `MetaTrader5 >= 5.0.5572`

## インストール

```bash
pip install -r requirements.txt
```

## 使い方

```bash
# MT5接続テスト（取引なし）
python main.py --dry-run

# テストトレード（最小ロットで1注文→即決済し、パイプライン全体を確認）
python main.py --test-trade

# 自動取引ループ起動（デフォルト6通貨ペア、H4、60秒間隔）
python main.py

# 単一通貨ペア指定
python main.py --instrument USD_JPY

# 複数ペア + 時間足・間隔変更
python main.py --instruments USD_JPY EUR_USD --granularity H1 --interval 30

# DEBUGログを出力
python main.py --verbose
```

## ファイル構成

```
FX自動取引/
├── main.py                    # エントリーポイント（起動・ループ制御）
├── src/
│   ├── mt5_client.py          # MT5 Python API ラッパー（BrokerClient実装）
│   ├── strategy/
│   │   └── ma_crossover.py    # RSI + MA クロスオーバー戦略
│   ├── risk_manager.py        # リスク管理・ポジションサイジング
│   ├── position_manager.py    # ポジション管理・SL/TP追従
│   ├── trading_loop.py        # メイン取引ループ
│   ├── config.py              # リスクパラメータ・定数管理
│   └── broker_client.py      # BrokerClient 抽象インターフェース
├── docs/                      # 設計ドキュメント
├── tests/                     # テストコード
├── data/                      # DBファイル・ログ出力先
└── requirements.txt
```

## MT5 Python API 既知の注意点

> **重要**: MetaTrader5 Python ライブラリ（v5.0.5572確認済み）では、
> `mt5.order_send(request=req)` というキーワード引数形式で呼び出すと
> **retcode=10013 (Invalid request)** が返されてしまう。
>
> 正しくは **`mt5.order_send(req)`** の位置引数形式を使うこと。
> `order_check` についても同様。

## リスクパラメータ（`src/config.py`）

| パラメータ | 値 | 説明 |
|---|---|---|
| `MAX_RISK_PER_TRADE` | 1% | 1トレードあたりの最大リスク |
| `MAX_LEVERAGE` | 10倍 | 自主制限レバレッジ（法定上限25倍） |
| `MAX_OPEN_POSITIONS` | 3 | 最大同時保有ポジション数 |
| `MAX_DAILY_LOSS` | 2% | 日次損失上限 |
| `DRAWDOWN_STOP` | 20% | ハードリミット（全停止） |
| `ADX_THRESHOLD` | 20 | トレンド判定閾値 |

## フェーズ

- ✅ **Phase 1**: 調査・設計（docs/ 参照）
- ✅ **Phase 2**: MT5実装・ペーパートレード（現在）
  - MT5クライアント実装
  - RSI+MAクロスオーバー戦略
  - リスク管理・ポジション管理
  - テストトレード動作確認済み（2026-03-02）
- 🔲 **Phase 3**: パフォーマンス評価・戦略改善
- 🔲 **Phase 4**: VPS運用検討
